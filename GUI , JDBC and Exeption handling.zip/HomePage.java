import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.logging.Level;

public class HomePage extends JFrame implements ActionListener {
    public JLabel l1;
    public JLabel l2;
    public JButton btn1;





    public HomePage() {
        setSize(450,500);
        setLayout(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setTitle("WELCOME USER");
        setVisible(true);

        l1= new JLabel("Announcement");
        setForeground(Color.MAGENTA);
        l2=new JLabel("Please Update your password after 30 days!!");
        setForeground(Color.MAGENTA);
        btn1=new JButton("EXIT");

        l1.setBounds(50, 120, 500, 200);
        l2.setBounds(120, 150, 400, 200);
        btn1.setBounds(170, 350, 150, 30);

        add(l1);
        add(l2);
        add(btn1);

        btn1.addActionListener(this);



    }

    public static void main(String[] args) {
        HomePage HomePage= new HomePage();
        HomePage.setVisible(true);

        try{
            for (UIManager.LookAndFeelInfo info:javax.swing.UIManager.getInstalledLookAndFeels()){
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(HomePage.class.getName()).log(Level.SEVERE,null,ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(HomePage.class.getName()).log(java.util.logging.Level.SEVERE,null,ex);
        } catch (IllegalAccessException ex){
            java.util.logging.Logger.getLogger(HomePage.class.getName()).log(java.util.logging.Level.SEVERE,null,ex);
        }catch (javax.swing.UnsupportedLookAndFeelException ex){
            java.util.logging.Logger.getLogger(HomePage.class.getName()).log(java.util.logging.Level.SEVERE,null,ex);
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==btn1){
            setDefaultCloseOperation(EXIT_ON_CLOSE);
            dispose();
        }

    }
}



















