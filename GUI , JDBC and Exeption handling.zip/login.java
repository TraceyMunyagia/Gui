import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class login extends JFrame implements ActionListener {

    JLabel l1, l2, l3;
    JTextField tf1;
    JButton btn1, btn2;
    JPasswordField p1;

    private String Driver = "com.mysql.cj.jdbc.Driver";
    private String url = "jdbc:mysql://localhost:3306/register";
    private String username = "root";
    private String password = "";

    private Connection connection;

    public login() {
        //initialize container properties
        setSize(700, 700);
        setLayout(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setTitle("Login Page");

        //initialize GUI components l1 = new JLabel("Login Page");
        //l1.setForeground(Color.blue);

        l1= new JLabel("Username:");
        l2 = new JLabel("Password:");
        tf1 = new JTextField();
        p1 = new JPasswordField();
        btn1 = new JButton("Login");
        btn2 = new JButton("Register");

        //deciding location for the components since we have no layout
        l1.setBounds(80, 160, 200, 30);
        l2.setBounds(80, 210, 200, 30);
        tf1.setBounds(300, 160, 200, 30);
        p1.setBounds(300, 210, 200, 30);
        btn1.setBounds(250, 270, 100, 30);
        btn2.setBounds(370, 270, 100, 30);

        //add to container
        add(l1);
        add(l2);
        add(tf1);
        add(p1);
        add(btn1);
        add(btn2);

        //actions
        btn1.addActionListener(this);
        btn2.addActionListener(this);

    }

    public static void main(String args[]) {
        login login = new login();
        login.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        // TODO Auto-generated method stub
        if (e.getSource()==btn1){
                String enteredUsername = tf1.getText();
                String enteredPassword = new String(p1.getPassword());
                try {
                    // Establish database connection
                    Connection conn = DriverManager.getConnection(url, username, password);

                    // Prepare SQL statement to check if user exists and password is correct
                    String sql = "SELECT * FROM login WHERE Name=? AND  Password=?";
                    PreparedStatement statement = conn.prepareStatement(sql);
                    statement.setString(1, enteredUsername);
                    statement.setString(2, enteredPassword);


                    ResultSet resultset = statement.executeQuery();
                    if (resultset.next()) {
                        JOptionPane.showMessageDialog(null, "Login successful!");
                        new HomePage();
                    } else {

                        JOptionPane.showMessageDialog(null, "Invalid login details. Please try again.");
                    }
                    resultset.close();
                    statement.close();
                    conn.close();
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(null, "Database error: " + ex.getMessage());
                }
            HomePage b= new HomePage();
            b.setVisible(true);
            this.setVisible(false);
            dispose();
        }
        if (e.getSource() == btn2) {

            Registration a = new Registration();
            a.setVisible(true);
            this.setVisible(false);
        }
    }

}

